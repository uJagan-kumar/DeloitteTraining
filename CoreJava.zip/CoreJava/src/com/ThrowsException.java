package com;
public class ThrowsException { 
	static void throwMethod() throws IllegalAccessException{ 
		System.out.println("Inside throwMethod."); 
		throw new IllegalAccessException("exception"); 
	} 
	public static void main(String args[]) { 
		try { 
			throwMethod(); 
			} 
		catch (IllegalAccessException e) 
		{ 
			System.out.println("Caught " + e); 
			} 
		} 
	}