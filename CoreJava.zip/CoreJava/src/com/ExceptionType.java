package com;
public class ExceptionType {
public static void main(String args[]) {
String s = null;
try {
System.out.println(s.length());
}
catch(Exception e) {
System.out.println("Exception 1");
}
finally {
try {
generateException();
}
catch(Exception e) {
System.out.println("Exception 2");
}
}
}
static void generateException()  {
throw new IllegalArgumentException();
}
}