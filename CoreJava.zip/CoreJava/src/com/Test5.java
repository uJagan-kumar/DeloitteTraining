package com;

public class Test5 
{  static void main(String[] data) 
{ 
	System.out.println("Test5"); 
	} 
}