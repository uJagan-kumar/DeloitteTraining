package com;

public class TestStart implements Runnable { boolean stoper = true; public void run() { System.out.println ("Run method Executed"); } public static void main (String[] argv) { TestStart objInt = new TestStart(); Thread threadX = new Thread(objInt); threadX.start(); threadX.start(); } }