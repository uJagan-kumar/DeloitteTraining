package com;

public class Code5 {
private int second = getFirst();
private int first = 6000;
private int getFirst() {
return first;
}
public static void main(String args[]) {
System.out.println(new Code5().second);
}
}