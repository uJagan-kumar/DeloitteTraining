package com;

import java.io.IOException;

public class ExceptQuest {
public ExceptQuest() throws IOException {
throw new IOException();
}
}
class ExtendedExceptQuest extends ExceptQuest
{

	public ExtendedExceptQuest() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	
}