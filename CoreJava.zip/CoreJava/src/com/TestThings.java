package com;
interface Things {
public static final int SIMPLE = 3; 
void work(int t); 
} 

public class TestThings implements Things { 
	public static void main(String [] args) { 
		int x = 5; 
		new TestThings().work(++x); 
		} 
	
		public void work(int s) {
			s += SIMPLE + ++s; 
			System.out.println("w " + s);
} 
		}