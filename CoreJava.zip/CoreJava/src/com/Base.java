package com;

public class Base {
 int ID = 3;
 public String name;
 public void methodA( int nn ){
  final int serialN = 11;
 class inner {
 void showResult(){
 System.out.println( "Rslt= " + serialN );
 }
 } // end class inner
 new inner().showResult();
 } // end methodA
}