package com;

interface InterfaceA {
String toString();
}
public class TestInterfaceA {
public static void main(String[] args) {
System.out.println(new InterfaceA() {
public String toString() {
return "test";
}
});
}
}