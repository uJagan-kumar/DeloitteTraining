package com;

class CatchableException extends Throwable { } 
class ThrowableException extends CatchableException { } 

public class ThrowCatchable { 
	public static void main(String args[]) { 
		try { 
			tryThrowing(); 
			} 
		catch(CatchableException c) { 
			System.out.println("Catchable caught"); 
			} 
		finally { 
			tryCatching(); 
			} 
		} 
	static void tryThrowing() throws CatchableException { 
		try { 
			tryCatching(); 
			throw new ThrowableException(); 
			} 
		catch(NullPointerException re) 
		{ 
			throw re; 
			} 
		} 
	static void tryCatching() { 
		System.out.println(null + " pointer exception"); 
		} 
	}