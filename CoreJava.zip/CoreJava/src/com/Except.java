package com;
public class Except {
private void method1() throws Exception {
throw new InterruptedException();
}
public void method2() {
try {
method1();
} catch (RuntimeException e) {
System.out.println("Caught Exception");
} catch (Exception e) {
System.out.println("Caught Runtime Exception");
}
}
public static void main(String args[]) {
Except e = new Except();	
e.method2();
}
}