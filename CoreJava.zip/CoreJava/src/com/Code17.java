package com;

public class Code17 { 
	public static void main(String args[]) { 
		new Code17(); 
		} 
	{ 
		System.out.print("Planet "); 
		} 
	{ 
		System.out.print("Welcome "); 
		} 
}
