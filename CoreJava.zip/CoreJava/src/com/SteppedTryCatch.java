package com;

import java.io.FileNotFoundException;
import java.io.IOException;

public class SteppedTryCatch {
public static void main(String[] args) {
try {
try {
try {
throw new Exception();
} catch(Exception e3) {
System.out.println("Exception 1");
throw new IOException();
}
} catch(IOException e2) {
System.out.println("Exception 2");
throw new FileNotFoundException();
}
} catch(FileNotFoundException e1) { System.out.println("Exception 3"); } } }