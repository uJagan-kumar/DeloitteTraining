package com;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TestCol4 { 
	public static void main(String[] args) { 
		Set h = new HashSet(); 
		h.add("One"); h.add("Two"); h.add("Three"); 
		h.add("Four"); h.add("One"); h.add("Four"); 
		
		List l = new ArrayList(); 
		l.add("One"); 
		l.add("Two"); 
		l.add("Three"); 
		h.retainAll(l); 
		
		System.out.println("H : " +h);
		System.out.println("L : " +l);
		System.out.println("Size:" + l.size() + h.size()); 
	} 
}