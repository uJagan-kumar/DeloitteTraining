package com;

public class A1 extends Thread 
{ 
	int i; 
	public void run() 
	{
		i++;
		i += 10;
	} 
	public void display(){	i++;}
	public static void main(String[] args) 
	{ 
		A1 a = new A1(); 
		a.display();
		a.start(); 
		System.out.print(a.i);
	}
}