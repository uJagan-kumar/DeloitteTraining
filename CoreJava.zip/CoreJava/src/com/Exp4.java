package com;

public class Exp4 
{ 
	static String s = "smile!.."; 
	public static void main(String[] args) { 
		new Exp4().s1(); 
		System.out.println(s); 
	} 
	void s1() { 
		try { 
			s2(); 
		} catch (Exception e) { 
			s += "morning"; 
		} 
	}
	void s2() throws Exception 
	{ 
		System.out.println("FIRST S2");
		s3();
		System.out.println("SECOND S2");
		s += "evening"; 
		s3(); 
		System.out.println("THIRD S2");
		s += "good"; 
	} 
	void s3() throws Exception 
	{ 
		throw new Exception(); 
	} 
}