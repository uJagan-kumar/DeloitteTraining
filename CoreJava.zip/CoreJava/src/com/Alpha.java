package com;

interface First {
int part();
}
public class Alpha 
{
	class A implements First 
	{
		public int part() 
		{ 
			return 1; 
		}
	}
	public int firstpart(First first) 
	{ 
		return first.part(); 
	}
	public void testFirst() {
			class A implements First 
			{
					public int part() { return 2; }
			}
			System.out.println(firstpart(new A()));
}
public static void main(String args[]) { 
	new Alpha().testFirst(); 
	} 
}
