package com;

interface InterfaceFirst { 
	int ID = 10; 
	void show(); 
} 
interface InterfaceSecond extends InterfaceFirst 
{ 
	int ID = 20; void show(); 
} 
class Implementation implements InterfaceSecond 
{ 
	public void show() { 
		System.out.println("ID:" + ID); 
	} 
} 
public class TestImplementation { 
	public static void main(String args[]) { 
		InterfaceSecond i2 = new Implementation(); 
		i2.show();
		InterfaceFirst i1 = i2; 
		i1.show(); 
	} 
}
