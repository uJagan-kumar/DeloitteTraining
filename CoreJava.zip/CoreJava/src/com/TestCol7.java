package com;

import java.util.ArrayList;
import java.util.Collections;

class Student implements Comparable // Code 1
{
String studentName;
Student() { }
Student(String studentName) {
this.studentName = studentName;
}
public String toString() {
return this.studentName;
}
// Code 2
@Override
public int compareTo(Object o) {
	Student s = (Student) o; 
	return this.studentName.compareTo(s.studentName);
}
}
public class TestCol7 {
public static void main(String args[]){
ArrayList students = new ArrayList();
students.add(new Student("Olive"));
students.add(new Student("Veni")); students.add(new Student("Krishna")); students.add(new Student("Daniel")); students.add(new Student("Elavarasan")); students.add(new Student("Praveen"));
Collections.sort(students); // Line 1
System.out.println(students); } }