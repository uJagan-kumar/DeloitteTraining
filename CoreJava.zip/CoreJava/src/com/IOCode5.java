package com;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Test implements Serializable{ int a = 10; } 
class Test2 extends Test implements Serializable { 
	int b; public String toString() { return "a = " + a + ", " + "b = " + b; }
}
public class IOCode5 {
public static void main(String args[]) throws FileNotFoundException,
IOException, ClassNotFoundException {
ObjectOutputStream out = new ObjectOutputStream(new
FileOutputStream("W:/ObjectData"));
Test2 t1 = new Test2();
t1.a = 20;
t1.b = 30;
out.writeObject(t1);
out.close();
ObjectInputStream in = new ObjectInputStream(new
FileInputStream("W:/ObjectData"));
Test2 t2 = (Test2) in.readObject(); // Line 1
System.out.println(t2);
}
}