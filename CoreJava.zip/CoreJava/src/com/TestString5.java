package com;

import java.util.StringTokenizer;

public class TestString5 { 
	public static void main(String args[]) { 
		String s = "Get Entertained"; 
		StringTokenizer st = new StringTokenizer(s, "t"); 
		while(st.hasMoreElements()) 
			System.out.print(st.nextToken()); 
		} 
}