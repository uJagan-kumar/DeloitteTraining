package com;

public class Trial { 
	public static void main(String argc[]) { 
		Trial tr = new Trial(); 
		tr.amethod(tr); 
	} 
	public void amethod(Trial tr) 
	{ 
		int i=99; 
		multi(tr);
		System.out.println(i); 
	}	
	public void multi(Trial tr) {
		//tr.i = tr.i*2;
	}
}