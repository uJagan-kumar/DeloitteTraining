package com;

abstract class Director 
{
protected String name;
Director(String name) { this.name = name; } 
abstract void occupation(); 
} 
class FilmDirector extends Director 
{ 
	FilmDirector(String name) { 
		super(name); 
	} 
	void occupation() { 
		System.out.println("Director " + name + " directs films"); 
	} 
} 
public class TestDirector { 
	public static void main(String[] args) { 
		FilmDirector fd = new FilmDirector("Manirathnam"); 
		fd.occupation(); 
		new Director("Manirathnam")
		{ 
			void occupation() { System.out.println("Director " + name + " also produces films"); 
			} 
		}.occupation(); 
	} 
}