package gc;

class A {
public A getMe() 
{
return this;
}
}
public class B extends A 
{
public static void main(String args[]) {
A a = new B() 
{
public A getMe() 
{ 
	return this; 
	} 
}; 
System.out.println(a.getClass().getSuperclass().getName()); 
} 
}