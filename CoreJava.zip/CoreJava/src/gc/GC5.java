package gc;

class Thing { }
class GC5 {
public static void main(String args[]) {
Thing h = new Thing();
Thing w = new Thing();
h = new GC5().kill(h, w);
}
public Thing kill(Thing h, Thing w) {
killSecondTime(h);
killSecondTime(w);
return w;
}
public void killSecondTime(Thing killable) {
killable = null;
}
}